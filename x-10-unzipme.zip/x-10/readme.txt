VIRUS INI TIDAK BERBAHAYA

BACA INI SEBELUM MEMBUKA FILE!
Jika kamu close command  setelah membuka file x-10.bat ikuti cara ini!
- buka task manager (ctrl+shift+esc / cmd+option+esc)
- tekan "run new task" atau "menjalankan tugas baru"
- tulis "explorer"
- tekan "OK"